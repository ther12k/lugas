/**
 * Canonical prepared-application graph (M4R1-001, M4R1-002).
 *
 * Built exactly once inside `defineApp()`: route/module structures are
 * snapshotted, declarations are grouped per path, different HTTP methods on
 * one path merge into a single frozen method map (order-independently), and
 * every surviving entry is classified once against the pinned Bun oracle.
 * Lugas descriptors compile once with the resolved error policy. The frozen
 * graph is the single input consumed by `serve()` — serving never re-reads
 * user configuration.
 *
 * Collision semantics (duplicates are fatal; module order never wins):
 * - same exact method + same path -> startup diagnostic naming both owners
 * - different methods + same path -> merge into one method map
 * - any-method value vs explicit-method map on one path -> explicit
 *   diagnostic: raw Bun resolves such overlap by insertion order, which is
 *   precisely the silent order-dependence Lugas forbids.
 *
 * Services stay live references by contract; structural immutability applies
 * to routing/policy ownership, not service contents.
 */
import { diagnostic, duplicateRoute } from "./diagnostics";
import { makeFact, descriptorFacts, type RouteFact } from "./route-fact";
import { classifyRoute } from "./classify-route";
import { compileAssets, type AssetsConfig } from "./assets";
import { compileSpa, type SpaConfig } from "./spa";
import { compileRoute } from "./compile-route";
import { defaultNotFound, defaultOnError, withErrorPolicy, type ErrorPolicy, type NotFoundPolicy } from "./error-policy";
import { isServiceDescriptor } from "../core/service";
import { createBudgetsContext, type BudgetsContext } from "./body-budget";
import { corsWrapHandler, type CompiledCorsPolicy } from "./cors";
import { wrapLogHandler, type CompiledLogging } from "./logging";
import { generateOpenApiDocument, createScalarHtml, type CompiledOpenApi } from "./openapi";
import { applySecureHeaders, type CompiledHealth, type CompiledSecureHeaders } from "./production";
import { createTelemetryRegistry, wrapTelemetryHandler, type CompiledTelemetry, type TelemetryRegistry } from "./telemetry";
import { applyCompression, applyEtag, type CompiledCompression, type CompiledEtag } from "./compression";
import type { LifecycleService, ShutdownOptions } from "./lifecycle";
import { createWebSocketHub, noteUpgradeServer, performUpgrade, type WebSocketHub, type WsRouteEntry } from "./websocket-hub";
import type { PipelineContext } from "./compile-pipeline";
import { problem } from "../core/response";
import type { ModuleDescriptor } from "../core/types";

export type SafeServeOptions = {
  port?: number | string;
  hostname?: string;
  development?: boolean;
  /**
   * Server body ceiling in bytes, forwarded to `Bun.serve`. Bun enforces it
   * while consuming the body: requests whose body is larger than this value
   * are rejected at the transport layer with a bare `413` (empty body) before
   * parsing, validation, or handler execution. Bodies of exactly this size
   * are accepted. See `docs/body-limits.md`.
   */
  maxRequestBodySize?: number;
  /**
   * Lifecycle shutdown options (ADR-0020): drain deadline (default 10s) and
   * opt-in SIGINT/SIGTERM handling. See `server.lugasLifecycle`.
   */
  shutdown?: ShutdownOptions;
  fetch?: (request: Request, server: Bun.Server<unknown>) => Response | Promise<Response>;
  routes?: Record<string, unknown>;
  [key: string]: unknown;
};

/** Frozen, Bun-ready output of preparation. Consumed by `serveApp()`. */
export type PreparedApp = {
  /** Compiled Bun route map; values are exactly what `Bun.serve` accepts. */
  readonly bunRoutes: Readonly<Record<string, unknown>>;
  /** Resolved not-found policy captured at definition time. */
  readonly notFound: NotFoundPolicy;
  /** Route facts captured at classification time (ADR-0017 single interpreter). */
  readonly facts: ReadonlyArray<RouteFact>;
  /** Service entries with declared lifecycle hooks (ADR-0020), declaration order. */
  readonly lifecycleServices: ReadonlyArray<LifecycleService>;
  /** Live services view handlers close over; descriptor slots fill at serve time. */
  readonly serviceSlots: Record<string, unknown>;
  /** Serve-time gate: Lugas handlers execute only after `gate` settles. */
  readonly trafficGate: { gate: Promise<void>; settled: boolean };
  /** Body-budget context (M7-003): app default, route budgets, ceiling slot. */
  readonly budgets: BudgetsContext;
  /** Compiled CORS policy (M8-001, ADR-0022); undefined when not configured. */
  readonly cors: CompiledCorsPolicy | undefined;
  /** Compiled logging policy (M8-003, ADR-0024); undefined when not configured. */
  readonly logging: CompiledLogging | undefined;
  /** WebSocket hub (M9-003, ADR-0028); null when the app declares no websocket routes. */
  readonly websocketHub: WebSocketHub | null;
  /** Compiled secure-headers policy (M9-004, ADR-0029); undefined when not configured. */
  readonly secureHeaders: CompiledSecureHeaders | undefined;
  /** Compiled health endpoint paths (M9-004, ADR-0029); undefined when not configured. */
  readonly health: CompiledHealth | undefined;
  /** Compiled telemetry hooks (M9-006, ADR-0032); undefined when not configured. */
  readonly telemetry: CompiledTelemetry | undefined;
  /** Request→telemetry-state registry for track() correlation (M9-006). */
  readonly telemetryRegistry: TelemetryRegistry;
  /** Compiled compression policy (M9-007, ADR-0033); undefined when not configured. */
  readonly compression: CompiledCompression | undefined;
  /** Compiled etag policy (M9-007, ADR-0033); undefined when not configured. */
  readonly etag: CompiledEtag | undefined;
};

function freezeContainers(value: Record<string, unknown>): Record<string, unknown> {
  // Freezes only containers this module created (the compiled route map and
  // its per-path method maps). User-owned values — native method maps,
  // Response/Blob instances, descriptors — pass through untouched.
  Object.freeze(value);
  return value;
}

type Declaration = { readonly owner: string; readonly entry: unknown; readonly moduleName: string | null };
const ROOT_OWNER = "app root routes";

/** Supported uppercase HTTP method keys (M5R1-003). */
const VALID_METHODS = new Set(["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]);
type MethodClaim = { readonly owner: string; readonly value: unknown; readonly moduleName: string | null };

function isPlainEntryObject(entry: unknown): entry is Record<string, unknown> {
  return typeof entry === "object" && entry !== null && !(entry instanceof Response) && !(entry instanceof Blob) && !("handler" in entry) && !("dir" in entry);
}

/** True when an entry serves all methods instead of named ones: functions,
 * native Response/Blob values, `{ dir }` maps, and Lugas descriptors. */
function isAnyMethodEntry(entry: unknown): boolean {
  return typeof entry === "function" || !isPlainEntryObject(entry);
}

export function prepareApp<TServices>(config: {
  routes?: Readonly<Record<string, unknown>> | undefined;
  modules?: ReadonlyArray<ModuleDescriptor<TServices, any>> | undefined;
  services: TServices;
  assets?: AssetsConfig | undefined;
  spa?: SpaConfig | undefined;
  bodyBudget?: number | undefined;
  cors?: CompiledCorsPolicy | undefined;
  logging?: CompiledLogging | undefined;
  openapi?: CompiledOpenApi | undefined;
  secureHeaders?: CompiledSecureHeaders | undefined;
  health?: CompiledHealth | undefined;
  telemetry?: CompiledTelemetry | undefined;
  compression?: CompiledCompression | undefined;
  etag?: CompiledEtag | undefined;
  notFound?: NotFoundPolicy | undefined;
  onError?: ErrorPolicy | undefined;
}): PreparedApp {
  const onError = config.onError ?? defaultOnError;

  // M7-004 (ADR-0020): split services into the live handler view and the
  // lifecycle-coordinated entries. The view prototype-chains to the user's
  // services object, so plain values keep the live-reference contract
  // (mutations stay visible). `service()` descriptors are shadowed with an
  // own slot that the coordinator fills once their `init` resolves — the raw
  // descriptor is never exposed to handlers.
  const lifecycleServices: LifecycleService[] = [];
  const serviceSlots = Object.create(
    typeof config.services === "object" && config.services !== null ? config.services : null,
  ) as Record<string, unknown>;
  if (typeof config.services === "object" && config.services !== null) {
    for (const [key, value] of Object.entries(config.services as Record<string, unknown>)) {
      if (isServiceDescriptor(value)) {
        serviceSlots[key] = undefined;
        lifecycleServices.push({ name: value.name, value: value.value, init: value.init, dispose: value.dispose });
      }
    }
  }

  // Traffic gate: replaced by serveApp() with the real init promise. Lugas
  // handlers await it, so no handler executes before initialization settles;
  // a startup failure answers held requests with a redacted 503 problem.
  // `settled` lets /ready answer synchronously (503) while init is pending —
  // readiness must answer, never hang (ADR-0029).
  //
  // Fast path: once initialization settles successfully (`trafficGate.settled === true`),
  // incoming requests invoke the handler directly, avoiding microtask
  // continuation queuing (`Promise.resolve().then()`) on synchronous route returns.
  // When pending or on initialization failure (`settled === false`), the gate
  // continuation holds traffic or rejects with the 503 problem.
  const trafficGate: { gate: Promise<void>; settled: boolean } = { gate: Promise.resolve(), settled: true };
  const gateHandler = (
    handler: (request: Request) => Response | Promise<Response>,
  ): (request: Request) => Response | Promise<Response> => {
    return (request: Request): Response | Promise<Response> => {
      if (trafficGate.settled) return handler(request);
      return Promise.resolve(trafficGate.gate).then(
        () => handler(request),
        () => problem(503, { title: "unavailable", status: 503, detail: "service initialization did not complete" }),
      );
    };
  };
  const budgetsCtx = createBudgetsContext(config.bodyBudget);
  const telemetryRegistry = createTelemetryRegistry();
  const compileLugasHandler = (routeId: string, descriptor: unknown): (request: Request) => Response | Promise<Response> => {
    const budget = (descriptor as { budget?: unknown }).budget;
    if (typeof budget === "number") budgetsCtx.routeBudgets.push(budget);
    const inner = gateHandler(withErrorPolicy(compileRoute(routeId, descriptor as never, serviceSlots, budgetsCtx).handler, onError, routeId));
    // M9-007 (ADR-0033): etag evaluates before compression (validators are
    // encoding-independent; a 304 never pays the encode cost) — both inside
    // logging/telemetry so those observe final statuses.
    let observed: (request: Request) => Response | Promise<Response> = inner;
    const compressionPolicy = config.compression;
    if (config.etag !== undefined) {
      const etagPolicy = config.etag;
      const innerHandler = observed;
      observed = (request: Request): Response | Promise<Response> =>
        Promise.resolve(innerHandler(request)).then((r) => applyEtag(etagPolicy, request, r, compressionPolicy));
    }
    if (compressionPolicy !== undefined) {
      const innerHandler = observed;
      observed = (request: Request): Response | Promise<Response> =>
        Promise.resolve(innerHandler(request)).then((r) => applyCompression(compressionPolicy, request, r));
    }
    // M9-006 (ADR-0032): telemetry wraps INSIDE logging — it mints the
    // request id (when logging.requestIds is on) and stamps x-request-id on
    // the response before the access log reads it: one identity source.
    const telemetryWrapped = config.telemetry !== undefined
      ? wrapTelemetryHandler(config.telemetry, telemetryRegistry, routeId, config.logging?.requestIds === true ? () => crypto.randomUUID() : undefined, observed)
      : observed;
    return config.logging !== undefined ? wrapLogHandler(config.logging, routeId, telemetryWrapped) : telemetryWrapped;
  };

  // M9-003 (ADR-0028): websocket descriptors compile through the same
  // pipeline — the synthetic route handler IS the upgrade decision, so
  // guards, schema slots, the traffic gate, and the error policy all apply
  // before the handshake. Raw event handlers register once per routeId.
  // The hub is created lazily on the first declared websocket descriptor,
  // preserving `websocketHub: null` and zero allocations when absent.
  let websocketHub: WebSocketHub | null = null;
  const getWebSocketHub = (): WebSocketHub => {
    if (websocketHub === null) websocketHub = createWebSocketHub();
    return websocketHub;
  };
  const compileWebSocketHandler = (routeId: string, descriptor: Record<string, unknown>): ((request: Request) => Response | Promise<Response>) => {
    const hub = getWebSocketHub();
    const message = descriptor.message as WsRouteEntry["message"];
    const open = descriptor.open as WsRouteEntry["open"] | undefined;
    const close = descriptor.close as WsRouteEntry["close"] | undefined;
    const drain = descriptor.drain as WsRouteEntry["drain"] | undefined;
    hub.routes.set(routeId, {
      message,
      ...(open !== undefined ? { open } : {}),
      ...(close !== undefined ? { close } : {}),
      ...(drain !== undefined ? { drain } : {}),
    });
    const synthetic = {
      before: descriptor.before,
      params: descriptor.params,
      query: descriptor.query,
      headers: descriptor.headers,
      handler: (context: PipelineContext): Response => performUpgrade(hub, routeId, context),
    };
    const inner = compileLugasHandler(routeId, synthetic);
    // Bun passes the receiving server as the route handler's second argument.
    // The compiled routes object is shared by every serve() of this app, so
    // the upgrade resolves the server that actually accepted the connection
    // per request (websocket-hub); a hub-level ref would go stale once a
    // later listener stops.
    return (request: Request, server?: Bun.Server<unknown>): Response | Promise<Response> => {
      if (server !== undefined) noteUpgradeServer(request, server);
      return inner(request);
    };
  };

  // Collect declarations per path, in declaration order (root first, then
  // modules in order). Ownership is tracked per method for diagnostics.
  const declarationsByPath = new Map<string, Declaration[]>();
  const declare = (owner: string, moduleName: string | null, source: Readonly<Record<string, unknown>> | undefined): void => {
    for (const [path, entry] of Object.entries(source ?? {})) {
      let list = declarationsByPath.get(path);
      if (list === undefined) {
        list = [];
        declarationsByPath.set(path, list);
      }
      list.push({ owner, entry, moduleName });
    }
  };
  declare(ROOT_OWNER, null, config.routes);
  for (const module_ of config.modules ?? []) {
    declare(`module '${module_.name}'`, module_.name, (module_.routes ?? {}) as Record<string, unknown>);
  }

  const facts: RouteFact[] = [];
  const rawDescriptors = new Map<string, unknown>();

  const compileMethodValue = (method: string, path: string, moduleName: string | null, value: unknown): unknown => {
    const kind = classifyRoute(value);
    if (kind.kind === "lugas-descriptor") {
      const declared = descriptorFacts(kind.descriptor as unknown as Record<string, unknown>);
      facts.push(makeFact({ method, path, module: moduleName, kind: "lugas", ...declared }));
      rawDescriptors.set(`${method} ${path}`, kind.descriptor);
    } else if (kind.kind === "lugas-websocket") {
      // ADR-0028: manifest vocabulary is unchanged — the route exists at its
      // path/method; the transport kind is not manifest records.
      facts.push(makeFact({ method, path, module: moduleName, kind: "lugas", ...descriptorFacts(kind.descriptor as Record<string, unknown>) }));
    } else if (kind.kind === "native-handler") {
      facts.push(makeFact({ method, path, module: moduleName, kind: "native", native: "handler", validates: [], guards: [] }));
    } else if (kind.kind === "native-response" || kind.kind === "native-file") {
      facts.push(makeFact({ method, path, module: moduleName, kind: "native", native: "static", validates: [], guards: [] }));
    } else if (kind.kind === "native-dir") {
      facts.push(makeFact({ method, path, module: moduleName, kind: "native", native: "directory", validates: [], guards: [] }));
    } else if (kind.kind !== "unsupported" && kind.kind !== "native-method-map") {
      // Opaque nested passthroughs record as static rows (ADR-0017 #4).
      facts.push(makeFact({ method, path, module: moduleName, kind: "native", native: "static", validates: [], guards: [] }));
    }
    if (kind.kind === "lugas-descriptor") {
      const routeId = `${method} ${path}`;
      return compileLugasHandler(routeId, kind.descriptor);
    }
    if (kind.kind === "lugas-websocket") {
      return compileWebSocketHandler(`${method} ${path}`, kind.descriptor);
    }
    if (kind.kind === "unsupported") {
      throw diagnostic("LUGAS_ROUTES_002", `unsupported route entry at ${method} ${path}`, {
        context: { method, path },
      });
    }
    // Raw Bun semantics (M4R1-004): function values serve verbatim.
    if (kind.kind === "native-handler") {
      const handler = kind.handler;
      return config.logging !== undefined ? wrapLogHandler(config.logging, `${method} ${path}`, handler) : handler;
    }
    if (kind.kind === "native-response") return kind.response;
    if (kind.kind === "native-file") return kind.file;
    if (kind.kind === "native-dir") return { dir: kind.path };
    // M5R1 correction: nested method maps must fail closed
    if (kind.kind === "native-method-map") {
      throw diagnostic("LUGAS_ROUTES_002", `nested method map is not allowed at ${method} ${path}`, { context: { method, path } });
    }
    // All route kinds handled above; this line is unreachable.
    throw diagnostic("LUGAS_ROUTES_002", `unreachable: unhandled route kind at ${method} ${path}`);
  };

  const compiled: Record<string, unknown> = {};
  for (const [path, declarations] of declarationsByPath) {
    const anyClaims: Declaration[] = [];
    const methodClaims = new Map<string, MethodClaim>();

    for (const { owner, entry, moduleName } of declarations) {
      const plain = isPlainEntryObject(entry) ? entry : undefined;
      if (plain === undefined) {
        anyClaims.push({ owner, entry, moduleName });
        continue;
      }
      for (const [method, value] of Object.entries(plain)) {
        // M5R1-003: validate method keys against the supported set.
        // M6R1-010: "ALL" is rejected too — Bun 1.4.0 does not accept it as a
        // method-map key (raw TypeError at serve time), so accepting it here
        // would defer the failure past Lugas diagnostics.
        if (!VALID_METHODS.has(method)) {
          throw diagnostic(
            "LUGAS_ROUTES_002",
            `unsupported route entry at ${method} ${path}`,
            { hint: "use uppercase HTTP methods: GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS — declare each method explicitly; there is no ALL key", context: { method, path } },
          );
        }
        const prior = methodClaims.get(method);
        if (prior !== undefined) {
          // Defensive: identical exact-method re-declarations are already
          // fatal in composition; assembly refuses them independently so no
          // caller can bypass ownership by reaching this layer directly.
          throw duplicateRoute(method, path, prior.owner, owner);
        }
        methodClaims.set(method, { owner, value, moduleName });
      }
    }

    if (anyClaims.length > 1) {
      throw duplicateRoute("*", path, anyClaims[0]!.owner, anyClaims[1]!.owner);
    }

    // M5R1 correction: empty method map must fail closed
    if (anyClaims.length === 0 && methodClaims.size === 0) {
      throw diagnostic("LUGAS_ROUTES_003", `unsupported route entry at ${path}: no valid handler found`, { context: { path } });
    }
    if (anyClaims.length === 1 && methodClaims.size > 0) {
      const firstMethod = methodClaims.keys().next().value as string;
      const methodOwner = methodClaims.get(firstMethod)!.owner;
      // Pinned-oracle enforcement: raw Bun keeps one value per path and would
      // resolve this overlap by insertion order. Lugas fails closed instead.
      throw duplicateRoute("*", path, anyClaims[0]!.owner, methodOwner);
    }

    if (anyClaims.length === 1) {
      const entry = anyClaims[0]!.entry;
      const moduleName = anyClaims[0]!.moduleName;
      const kind = classifyRoute(entry);
      // Raw Bun semantics (M4R1-004): function values serve verbatim,
      // untouched by the framework pipeline.
      if (kind.kind === "native-handler") {
        const handler = kind.handler;
        compiled[path] = config.logging !== undefined ? wrapLogHandler(config.logging, `* ${path}`, handler) : handler;
        facts.push(makeFact({ method: "*", path, module: moduleName, kind: "native", native: "handler", validates: [], guards: [] }));
        continue;
      }
      // ADR-0017 #3: bare descriptors become one visible "*" lugas record.
      if (kind.kind === "lugas-descriptor") {
        const declared = descriptorFacts(kind.descriptor as unknown as Record<string, unknown>);
        facts.push(makeFact({ method: "*", path, module: moduleName, kind: "lugas", ...declared }));
        rawDescriptors.set(`* ${path}`, kind.descriptor);
      } else if (kind.kind === "lugas-websocket") {
        facts.push(makeFact({ method: "*", path, module: moduleName, kind: "lugas", ...descriptorFacts(kind.descriptor as Record<string, unknown>) }));
      } else if (kind.kind === "native-response" || kind.kind === "native-file") {
        facts.push(makeFact({ method: "*", path, module: moduleName, kind: "native", native: "static", validates: [], guards: [] }));
      } else if (kind.kind === "native-dir") {
        facts.push(makeFact({ method: "*", path, module: moduleName, kind: "native", native: "directory", validates: [], guards: [] }));
      }
      if (kind.kind === "lugas-descriptor") {
        const routeId = `* ${path}`;
        compiled[path] = compileLugasHandler(routeId, kind.descriptor);
      } else if (kind.kind === "lugas-websocket") {
        compiled[path] = compileWebSocketHandler(`* ${path}`, kind.descriptor);
      } else if (kind.kind === "unsupported") {
        throw diagnostic("LUGAS_ROUTES_003", `unsupported route entry at ${path}`, {
          context: { path },
        });
      } else if (kind.kind === "native-response") {
        compiled[path] = kind.response;
      } else if (kind.kind === "native-file") {
        compiled[path] = kind.file;
      } else if (kind.kind === "native-dir") {
        compiled[path] = { dir: kind.path };
      } else {
        compiled[path] = kind.map;
      }
      continue;
    }

    const methodMap: Record<string, unknown> = {};
    for (const [method, claim] of methodClaims) {
      methodMap[method] = compileMethodValue(method, path, claim.moduleName, claim.value);
    }
    compiled[path] = Object.freeze(methodMap);
  }

  // Assets (ADR-0018): ownership is validated against every declared API
  // path, then compiled to native Bun route values. Asset entries never
  // produce manifest facts and bypass the Lugas request pipeline — which is
  // exactly why they are incompatible with a CORS policy (M8-001, ADR-0022):
  // headers cannot be enforced on natively served values, so configuring
  // both fails closed instead of serving un-policy'd responses.
  if (config.cors !== undefined && config.assets !== undefined) {
    throw diagnostic("LUGAS_CORS_004", "defineApp(): cors cannot be combined with 'assets'", {
      hint: "asset routes bypass the framework response pipeline, so CORS cannot be enforced on them; serve assets from a separate app or convert them to handlers",
    });
  }
  const assetRoutes = compileAssets(config.assets, new Set(declarationsByPath.keys()));
  Object.assign(compiled, assetRoutes);

  // CORS (M8-001, ADR-0022): the policy wraps every compiled handler as the
  // outermost layer (outside the traffic gate and error policy, so held 503s
  // and error 500s carry it too). Static native values cannot be wrapped
  // without losing their serving semantics — they fail closed here. No
  // routes are synthesized and no path matching is reimplemented: preflights
  // that match no declared OPTIONS/any-method entry reach the wrapped fetch
  // fallback through Bun's own routing.
  // M9-004 (ADR-0029): secure-headers policy, fill-if-absent, applied to
  // every compiled handler BEFORE the CORS pass (CORS stays outermost so
  // preflights skip the policy). Static values (Response/Blob/{ dir }) and
  // assets are not functions — they bypass the pipeline and carry no policy
  // headers, same truth as CORS and guards.
  if (config.secureHeaders !== undefined) {
    // The optional server argument is Bun's route-handler contract: it must
    // survive every outer wrap, or websocket upgrades lose their receiving
    // server (see compileWebSocketHandler's boundary note).
    const wrapHeaders = (handler: (request: Request, server?: Bun.Server<unknown>) => Response | Promise<Response>): ((request: Request, server?: Bun.Server<unknown>) => Response | Promise<Response>) => {
      if (config.secureHeaders === undefined) return handler;
      const policy = config.secureHeaders;
      return async (request: Request, server?: Bun.Server<unknown>) => {
        const response = await handler(request, server);
        return applySecureHeaders(policy, response);
      };
    };
    for (const [path, value] of Object.entries(compiled)) {
      if (typeof value === "function") {
        compiled[path] = wrapHeaders(value as (request: Request) => Response | Promise<Response>);
        continue;
      }
      if (typeof value !== "object" || value === null || value instanceof Response || value instanceof Blob) continue;
      const record = value as Record<string, unknown>;
      const keys = Object.keys(record);
      if (keys.length === 1 && typeof record["dir"] === "string") continue;
      const wrappedMap: Record<string, unknown> = {};
      for (const [method, entry] of Object.entries(record)) {
        // Static method-map entries (native file/Response values) are
        // preserved verbatim — they bypass the pipeline and carry no policy
        // headers (documented truth above); silently dropping them from the
        // rebuilt map turned every native entry into an empty map (CA-1).
        wrappedMap[method] = typeof entry === "function"
          ? wrapHeaders(entry as (request: Request) => Response | Promise<Response>)
          : entry;
      }
      compiled[path] = Object.freeze(wrappedMap);
    }
  }

  if (config.cors !== undefined) {
    const rejectStatic = (path: string, method: string | null, kind: string): never => {
      const at = method === null ? path : `${method} ${path}`;
      throw diagnostic("LUGAS_CORS_004", `defineApp(): cors requires the framework response pipeline, but a ${kind} is declared at ${at}`, {
        hint: "convert the static value to a handler (function or route()) or serve it from an app without cors",
        context: { path, ...(method !== null ? { method } : {}), kind },
      });
    };
    for (const [path, value] of Object.entries(compiled)) {
      if (typeof value === "function") {
        compiled[path] = corsWrapHandler(config.cors, value as (request: Request) => Response | Promise<Response>);
        continue;
      }
      if (value instanceof Response) rejectStatic(path, null, "static Response value");
      if (value instanceof Blob) rejectStatic(path, null, "Bun.file/Blob value");
      if (typeof value !== "object" || value === null) rejectStatic(path, null, "static value");
      const record = value as Record<string, unknown>;
      const keys = Object.keys(record);
      if (keys.length === 1 && typeof record["dir"] === "string") rejectStatic(path, null, "native { dir } mount");
      // Method maps built above are frozen; wrap into a fresh frozen map.
      const wrappedMap: Record<string, unknown> = {};
      for (const [method, entry] of Object.entries(record)) {
        if (typeof entry !== "function") {
          const kind = entry instanceof Response ? "static Response value" : entry instanceof Blob ? "Bun.file/Blob value" : "static value";
          rejectStatic(path, method, kind);
        }
        wrappedMap[method] = corsWrapHandler(config.cors, entry as (request: Request) => Response | Promise<Response>);
      }
      compiled[path] = Object.freeze(wrappedMap);
    }
  }

  // OpenAPI & Scalar endpoints (M8-004, ADR-0025):
  // Generated and mounted as standard framework handlers.
  // Validate collision against declared API routes and asset mappings first.
  if (config.openapi !== undefined) {
    const docPath = config.openapi.path;
    const uiPath = config.openapi.uiPath;
    const existingPaths = new Set(declarationsByPath.keys());
    if (config.assets?.files) {
      for (const f of Object.keys(config.assets.files)) existingPaths.add(f);
    }
    if (existingPaths.has(docPath)) {
      throw diagnostic("LUGAS_OPENAPI_002", `defineApp(): openapi.path '${docPath}' collides with an existing route or asset`, {
        hint: "configure a different path: openapi: { path: '/api-docs.json' }",
        context: { path: docPath },
      });
    }
    if (uiPath !== null && existingPaths.has(uiPath)) {
      throw diagnostic("LUGAS_OPENAPI_002", `defineApp(): openapi.ui.path '${uiPath}' collides with an existing route or asset`, {
        hint: "configure a different UI path: openapi: { ui: { path: '/scalar' } }",
        context: { path: uiPath },
      });
    }

    const doc = generateOpenApiDocument(config.openapi, facts, rawDescriptors);
    const docJson = JSON.stringify(doc);

    let docHandler: (request: Request) => Response | Promise<Response> = () => {
      return new Response(docJson, {
        headers: { "content-type": "application/json; charset=utf-8" },
      });
    };
    if (config.logging !== undefined) {
      docHandler = wrapLogHandler(config.logging, `GET ${docPath}`, docHandler);
    }
    if (config.cors !== undefined) {
      docHandler = corsWrapHandler(config.cors, docHandler);
    }
    compiled[docPath] = Object.freeze({ GET: docHandler });
    facts.push(makeFact({ method: "GET", path: docPath, module: null, kind: "native", native: "handler", validates: [], guards: [] }));

    if (uiPath !== null) {
      const html = createScalarHtml(docPath, config.openapi.document.title);
      let uiHandler: (request: Request) => Response | Promise<Response> = () => {
        return new Response(html, {
          headers: { "content-type": "text/html; charset=utf-8" },
        });
      };
      if (config.logging !== undefined) {
        uiHandler = wrapLogHandler(config.logging, `GET ${uiPath}`, uiHandler);
      }
      if (config.cors !== undefined) {
        uiHandler = corsWrapHandler(config.cors, uiHandler);
      }
      compiled[uiPath] = Object.freeze({ GET: uiHandler });
      facts.push(makeFact({ method: "GET", path: uiPath, module: null, kind: "native", native: "handler", validates: [], guards: [] }));
    }
  }

  // M9-004 (ADR-0029): health endpoints mount as framework routes OUTSIDE
  // the traffic gate — that boundary IS the liveness/readiness distinction.
  // Liveness answers 200 whenever the server accepts connections (a booting
  // process is alive); readiness awaits the gate (503 while held or after a
  // startup failure). Collisions with declared routes/assets fail closed.
  if (config.health !== undefined) {
    const existingPaths = new Set(declarationsByPath.keys());
    if (config.assets?.files) {
      for (const f of Object.keys(config.assets.files)) existingPaths.add(f);
    }
    for (const [label, path] of [["liveness", config.health.livenessPath], ["readiness", config.health.readinessPath]] as const) {
      if (existingPaths.has(path)) {
        throw diagnostic("LUGAS_HEALTH_002", `defineApp(): health ${label} path '${path}' collides with an existing route or asset`, {
          hint: "rename the health endpoint: health: { livenessPath: '/healthz' }",
          context: { path },
        });
      }
      existingPaths.add(path);
    }
    const healthJson = (code: number, status: string): Response =>
      new Response(JSON.stringify({ status }), {
        status: code,
        headers: { "content-type": "application/json; charset=utf-8" },
      });
    const livenessHandler = (): Response => healthJson(200, "ok");
    const readinessHandler = (): Response =>
      healthJson(trafficGate.settled ? 200 : 503, trafficGate.settled ? "ready" : "unavailable");
    for (const [path, handler] of [[config.health.livenessPath, livenessHandler], [config.health.readinessPath, readinessHandler]] as const) {
      let mounted: (request: Request) => Response | Promise<Response> = handler;
      if (config.logging !== undefined) mounted = wrapLogHandler(config.logging, `GET ${path}`, mounted);
      if (config.secureHeaders !== undefined) {
        const policy = config.secureHeaders;
        const inner = mounted;
        mounted = async (request: Request) => applySecureHeaders(policy, await inner(request));
      }
      if (config.cors !== undefined) mounted = corsWrapHandler(config.cors, mounted);
      compiled[path] = Object.freeze({ GET: mounted });
      facts.push(makeFact({ method: "GET", path, module: null, kind: "native", native: "handler", validates: [], guards: [] }));
    }
  }

  // ADR-0037: SPA navigations mount after every other owner so ownership can
  // be validated against routes, assets, health, and OpenAPI paths, and so
  // the policy wraps (logging, secureHeaders, CORS) apply to the shell
  // exactly as they do to health endpoints. Native static values still bypass
  // the pipeline (unchanged, documented); the shell deliberately does not.
  if (config.spa !== undefined) {
    const ownedHealth = new Set<string>();
    const ownedOpenApi = new Set<string>();
    if (config.health !== undefined) {
      ownedHealth.add(config.health.livenessPath);
      ownedHealth.add(config.health.readinessPath);
    }
    if (config.openapi !== undefined) {
      ownedOpenApi.add(config.openapi.path);
      if (config.openapi.uiPath !== null) ownedOpenApi.add(config.openapi.uiPath);
    }
    const spaRoutes = compileSpa(config.spa, {
      routes: new Set(declarationsByPath.keys()),
      assets: new Set(Object.keys(assetRoutes)),
      health: ownedHealth,
      openapi: ownedOpenApi,
    });
    for (const [path, methodMap] of Object.entries(spaRoutes)) {
      const wrappedMap: Record<string, unknown> = {};
      for (const [method, entry] of Object.entries(methodMap as Record<string, (request: Request) => Response | Promise<Response>>)) {
        let mounted: (request: Request) => Response | Promise<Response> = entry;
        if (config.logging !== undefined) mounted = wrapLogHandler(config.logging, `${method} ${path}`, mounted);
        if (config.secureHeaders !== undefined) {
          const policy = config.secureHeaders;
          const inner = mounted;
          mounted = async (request: Request) => applySecureHeaders(policy, await inner(request));
        }
        if (config.cors !== undefined) mounted = corsWrapHandler(config.cors, mounted);
        wrappedMap[method] = mounted;
        facts.push(makeFact({ method, path, module: null, kind: "native", native: "handler", validates: [], guards: [] }));
      }
      compiled[path] = Object.freeze(wrappedMap);
    }
  }

  return Object.freeze({
    bunRoutes: Object.freeze(freezeContainers(compiled)),
    notFound: config.notFound ?? defaultNotFound,
    facts: Object.freeze(facts),
    lifecycleServices: Object.freeze(lifecycleServices),
    serviceSlots,
    trafficGate,
    budgets: budgetsCtx,
    cors: config.cors,
    logging: config.logging,
    websocketHub,
    secureHeaders: config.secureHeaders,
    health: config.health,
    telemetry: config.telemetry,
    telemetryRegistry,
    compression: config.compression,
    etag: config.etag,
  });
}
