/** Generated build constant — synced from package.json by scripts/sync-version.ts. Do not edit by hand. */
export const FRAMEWORK_VERSION = "0.1.0-beta.6";
